package com.rentitnow;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RentItNowApplicationTests {

	@Test
	void contextLoads() {
	}

}
